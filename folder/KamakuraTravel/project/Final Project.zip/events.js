"use strict";

var dayEvent = new Array();

dayEvent[1] = "";
dayEvent[2] = "<br /><a href='#'>Kōtoku-in</a><br />8:00 am-5:30pm <br />$2";
dayEvent[3] = "";
dayEvent[4] = "<br /><a href='#'>Kōtoku-in</a><br />8:00 am-5:30pm <br />$2";
dayEvent[5] = "<br /><a href='#'>Tokamachi Ajisai Park Hydrangea Festival</a><br />whole day<br />Free";
dayEvent[6] = "<br /><a href='#'>Tokamachi Ajisai Park Hydrangea Festival</a><br />whole day<br />Free";
dayEvent[7] = "<br /><a href='#'>Tanabata Festival</a><br /> whole day<br /> Free";


dayEvent[8] = "";
dayEvent[9] = "";
dayEvent[10] = "<br /><a href='#'>Tokamachi Ajisai Park Hydrangea Festival</a><br />whole day<br />Free";
dayEvent[11] = "<br /><a href='#'>Enoshima Tenno Festival</a><br />9:30 am-6pm<br />Free";
dayEvent[12] = "<br /><a href='#'>Enoshima Tenno Festival</a><br />9:30 am-6pm<br />Free";
dayEvent[13] = "<br /><a href='#'>Enoshima Tenno Festival</a><br />9:30 am-6pm<br />Free";
dayEvent[14] = "<br /><a href='#'>Enoshima Tenno Festival</a><br />9:30 am-6pm<br />Free";

dayEvent[15] = "";
dayEvent[16] = "<br /><a href='#'>Engakuji</a><br />8 am<br />Free";
dayEvent[17] = "";
dayEvent[18] = "<br /><a href='#'>Shichirihama Beach</a><br />whole day<br />Free";
dayEvent[19] = "<br /><a href='#'>Enoshima</a><br />3pm<br />Free";
dayEvent[20] = "<br /><a href='#'>Kamakura Fireworks</a><br />7 pm <br />Free";
dayEvent[21] = "<br /><a href='#'>Kamakura Fireworks</a><br />7 pm <br />Free";

dayEvent[22] = "<br /><a href='#'>Marine Day</a><br />whole day <br />Free";
dayEvent[23] = "";
dayEvent[24] = "<br /><a href='#'>Goryo Shrine</a><br />whole day<br />Free";
dayEvent[25] = "";
dayEvent[26] = "";
dayEvent[27] = "<br /><a href='#'>Kamakura Seaside Park</a><br />whole day<br />Free";
dayEvent[28] = "<br /><a href='#'>Kamakura Seaside Park</a><br />whole day<br />Free";

dayEvent[29] = ""
dayEvent[30] = "<br /><a href='#'>Tsurugaoka Hachimangu Reitaisai Festival</a><br />7:30 pm<br />Free"
dayEvent[31] = "";
